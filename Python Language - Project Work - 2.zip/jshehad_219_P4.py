#-------------------------------------------------------------------------------
# Name: Jihad Shehadeh
# Project 4
# Due Date: 04/02/2017
#-------------------------------------------------------------------------------
# Honor Code Statement: I received no assistance on this assignment that
# violates the ethical guidelines set forth by professor and class syllabus.
#-------------------------------------------------------------------------------
# References: Used none
#-------------------------------------------------------------------------------
# Comments and assumptions: None
#-------------------------------------------------------------------------------
# NOTE: width of source code should be <= 80 characters to be read on-screen.
#2345678901234567890123456789012345678901234567890123456789012345678901234567890
#		10 		  20		30		  40		50		  60		70		  80
#-------------------------------------------------------------------------------

def make_empty_board(n):
	empty = [] # create a list containing n amount on empty list
	finalist =[] # total result
	sec = 0 # second counter
	counter = 0 # first counter
	if counter <= n: # count n amount of empty list needed
		for i in range(n):
			empty.append([])# adds empty list
			counter +=1
			for i in range(len(empty)):
				for x in range(n):
					empty[i].append(None)# adds None into the 2d list
			if sec <= n:
				for a in range(n):
					finalist += empty[:]#adds the list to a new list but still is an allasis
					sec += 1
				return finalist
			
def is_valid_location(loc,puzzle):
	row = loc[0] #indexing the first digit in the tuple
	col = loc[1] #indexing the second digit in the tuple
	target = []
	if row < 0: # if digit is negative returns false
		return False
	else:
		if row < len(puzzle):
			for i in puzzle[row]:
				target.append(i)
			if col < len(target): # if col exist in len(target)
				target = target[col]
				return True
			else:
				return False
		else:
			return False		
			
def is_complete(puzzle):
	vs = []# contains a flatten list
	for d1 in puzzle:
		for d2 in d1:
			vs.append(d2) #created a flattened list
	for k in vs:
		while k == None:# does it contain None?
			return False
	else:
		return True
		
def get_value_at_location(puzzle, loc):
	row = loc[0]#indexing the first digit in the tuple
	col = loc[1]#indexing the second digit in the tuple
	for i in puzzle:
		target = puzzle[row]
		lock = target[col]
	print (lock)# returns locations
	
def set_location(puzzle,value, loc):
	location = is_valid_location(loc,puzzle)
	if location == True:
		row = loc[0]#indexing the first digit in the tuple
		col = loc[1]#indexing the second digit in the tuple
		if puzzle[row][col] == None:# if it equals none 
			puzzle[row].pop([col][0])
			puzzle[row].insert(col,value)# change it
			return True
		else:
			return False
	else:
		return False
	
def unset_location(puzzle, loc):
	location = is_valid_location(loc,puzzle)
	if location == True:
		row = loc[0]#indexing the first digit in the tuple
		col = loc[1]#indexing the second digit in the tuple
		if puzzle[row][col] != None:# if it doesnt equal none
			puzzle[row].pop([col][0])
			puzzle[row].insert(col,None)# change it
			return True
		else:
			return False
	else:
		return False	
	
def get_size(puzzle):
	for i in puzzle:
		row = len(i)# gives you the size length of the puzzle
		return row

def get_valid_numbers(size):
	puzzle = []
	for i in range(1,size+1):
		puzzle.append(i)# gives you a one diminsion list
	return puzzle

def contains_only_valid_symbols(puzzle, complete):# struggling
	if complete == True:
		for i in puzzle:
			for j in i:
				a = 0
				while a in range(len(puzzle)): # if it contains only num 
					if type(j) == int:
						a += 1
					return False
				else:
					return True
	elif complete == False:
		for i in puzzle:
			for j in i:
				a = 0
				while a in range(len(puzzle)): # if it contains a mix of int and none
					if type(j) == int:
						a += 1
						return True
					else:
						return False
	
def has_repeat(xs, v):
	if len(xs) != len(set(xs)):#comparing the set lengths(not the right medthod for this problem)
		return True
	else:
		return False
		
def get_row(puzzle, row_index):
	if row_index >= 0:
		if len(puzzle) > row_index:
			return puzzle[row_index]# gives you a row at row_index 
		elif len(puzzle) <= row_index:
			print (None)
	else:
		print (None)

def is_valid_row(puzzle, row_index, complete):
	if row_index >=0:
		index = get_row(puzzle, row_index)
	else:
		return False
	for i in index:
		if has_repeat(index, i) == True:# checks wheather or not is true
			return False
		else:
			return True
			
def get_column(puzzle, col_index):
	new_col = []
	if len(puzzle) > col_index:
		for x in puzzle:
			new_col.append(x[col_index])
		return new_col #gives you col at col_index
	elif len(puzzle) <= col_index:
		print (None)

def get_board_string(puzzle):
	new = []
	new2= []
	for xs in puzzle:
		for x in xs:
			new.append(x) # flattened a 2d list
	for n in new:
		if type(n) != int:
			new2.append('.') # if anything other than a num change it to a dot
		else:
			new2.append(n) # format string to display a board
	return "	[0]	[1]	[2]\n	-------------\n[0]	{0} | {1} | {2} |\n[1]	{4} | {5} | {6} |\n[2]	{7} | {8} | {9} |\n	-------------" .format(new2)

def is_symmetric(puzzle):
    puzzle_size = len(puzzle)
    if not puzzle: # checks to see if the list is empty
        return True
    if puzzle_size != len(puzzle[0]): # check to make sure the list is a square
        return False
    i = 0
    while i < puzzle_size:
        j = 0
        while j < puzzle_size:
            if puzzle[i][j] != puzzle[j][i]:
                return False
            j = j + 1 # close the loop
        i = i + 1 # close the loop
    return True
	
'''
def is_valid_cage_solution(puzzle, op, expected_total, locations):
	loco = []
	for i in locations:
		for tup in i:
			col = locations[i][tup]
			if row == puzzle:
				loco += col
		print(loco)
		if op == '+':
			loco = sum(loco)
		elif op == '-':
			loco = difference(loco)
		elif op == 'x':
			for x in loco:
				loco *= x
	if expected_total == loco:
		return True
	else:
		return False
'''