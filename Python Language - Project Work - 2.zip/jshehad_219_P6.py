#-------------------------------------------------------------------------------
# Name: Jihad Shehadeh
# Project 6
# Due Date: 05/07/2017
#-------------------------------------------------------------------------------
# Honor Code Statement: I received no assistance on this assignment that
# violates the ethical guidelines set forth by professor and class syllabus.
#-------------------------------------------------------------------------------
# References: Used none
#-------------------------------------------------------------------------------
# Comments and assumptions: None
#-------------------------------------------------------------------------------
# NOTE: width of source code should be <= 80 characters to be read on-screen.
#2345678901234567890123456789012345678901234567890123456789012345678901234567890
#		10 		  20		30		  40		50		  60		70		  80
#-------------------------------------------------------------------------------

from math import *

class Train:
	def __init__(self, name, max_passengers,speed_fps):
		self.name = name # Train Name
		self.max_passengers = max_passengers # Max Capacity
		self.num_passengers = 0 # Default passengers
		self.speed_fps  = speed_fps # feet per second
		self.speed_mph = (self.speed_fps * .681818) # miles per hour
		
	def __str__(self): # String format
		return "Train named %s with %d passengers will travel at %.2fmph" % (self.name,self.num_passengers,round(self.speed_mph,2))
		
	def time_to_travel(self,distance_feet):
		self.distance_feet = distance_feet
		time = int(self.distance_feet/self.speed_fps) # Dividing distance by speed gives time
		return time
		
	def unload_passengers(self, num_people):
		if self.num_passengers >= num_people:
			self.num_passengers -= num_people # record number of people getting off
		else: # if number of people exceed the number of passengers getting off raise an error
			num_people -= self.max_passengers
			raise TrainCapacityException(num_people,"empty")

	def load_passengers(self, num_people):
		if (self.max_passengers is None) or (self.num_passengers + num_people <= self.max_passengers):
			self.num_passengers += num_people # record number of people getting on
		else: # if number of people exceed the number of max capactiy getting on raise an error
			num_people -= self.max_passengers
			raise TrainCapacityException(num_people,"full")

class TrainCapacityException(Exception):
	def __init__(self,number,issue="full"):
		self.number = number
		self.issue = issue
	def __str__(self):
		if self.issue == "full": # Expection String format
			return str(self.number) + ' passengers cannot be loaded because the train is full!'
		else:
			return str(self.number) + ' passengers cannot be unloaded because the train is empty!'

class City:
	def __init__(self,name,loc_x,loc_y,stop_time):
		self.name = name # Name of the City
		self.loc_x = loc_x # X Coordinates 
		self.loc_y = loc_y # Y Coordinates
		self.stop_time = stop_time # in Seconds
		self.stop_time_m = (stop_time / 60) # in Minutes
		
	def __str__(self): # String Formats
		return "%s (%d,%d). Exchange time: %.2f minutes" % (self.name,self.loc_x,self.loc_y,self.stop_time_m)
	
	def __eq__(self,other): # if the Coordinates are the same
		return (self.loc_x == other.loc_x) and (self.loc_y == other.loc_y)
	
	def distance_to_city(self,city): # distance from two Coordinates
		distance = sqrt(((city.loc_x - self.loc_x)**2) + ((city.loc_y - self.loc_y)**2))
		return distance

class Journey:
	def __init__(self, train, destinations=None, start_time=0):
		
		if type(train) != str: # check input if correct
			self.train = train
		else:
			raise TypeError("wrong")
			
		if (destinations != None) and (type(destinations) != str): # check input if correct
			self.destinations = destinations
		elif destinations == None and (type(destinations) != str):
			self.destinations = []
		else:
			raise TypeError("wrong")
			
		self.start_time = start_time
	
	def __str__(self): # format Journey string
		new = []
		all = ""
		for i in self.destinations:
			new.append(str(i))
		for c in new:
			all += "\n\t" + c
		return "Journey with " + str(len(self.destinations)) + " stops:" + all + "\nTrain Information: " + str(self.train) + "\n"
		
	def add_destination(self, city):
		self.city = self.destinations.append(city)
	
	def city_in_journey(self, city):
		self.city = city
		if self.city in self.destinations: # check if city is in the destinations list
			return True
		return False 
	
	def check_journey_includes(self, start_city, dest_city): # check if path existed
		self.start_city = start_city
		self.dest_city = dest_city
		tof = False
		for i in range(len(self.destinations)):
			if (self.start_city == self.destinations[i]):
				tof = True
			if (self.dest_city == self.destinations[i]):
				return tof
		return False
		
	# def total_journey_distance(self):
		
	# def city_arrival_time(self, city):
	
	# def city_departure_time(self, city):
	
	# def total_journey_time(self):
	
	# def all_passengers_accommodated(self, unload_list, load_list):
	
	