def read_info_file(filename):

	each_line = []
	twoD = []
	keys = []
	fullvalues = []
	values = []
	caseSensitve = []
	convertNum = []	
	non = []
	tof = []
	res = []
	dict = {}

	# File ----------------------------------------
	file = open(filename,"r")
	file.readline()
	info = file.read()
	file.close()

	# MAIN -----------------------------------------
	all_line = info.replace('\n',' ').split('"')
	for i in range(len(all_line)):
		if all_line[i] != ',':
			each_line.append(all_line[i])
			
	for i in range(0, len(each_line[:-1]), 6):
		twoD.append(each_line[:-1][i:i+6])

	# Make two list, one for keys and one for values
	for i in twoD:
		for k in range(len(i)):
			if k == 1:
				keys.append(i[k])
	for i in twoD:
		for v in range(len(i)):
			if v != 1:
				fullvalues.append(i[v])

	# Fixing ---------------------------------------
	j=0
	for s in fullvalues:
		fullvalues[j]=s.strip(' ,')
		j+=1

	# Title ---------------------------------------
	for cap in fullvalues:
		if cap.upper():
			caseSensitve.append(cap.title())
		else:
			caseSensitve.append(cap)

	# Changing it to an Integers ---------------------------------------
	for num in caseSensitve:
		if num.isdigit():
			convertNum.append(int(num))
		else:
			convertNum.append(num)

	# Changing it to a NoneType ---------------------------------------
	for word in convertNum:
		if word == '':
			non.append(None)
		else:
			non.append(word)

	# Fix char case True or False
	for choice in non:
		if choice == ("True"):
			tof.append(True)
		elif choice == ("False"):
			tof.append(False)
		else:
			tof.append(choice)

	# Grouping it into a 2d values ---------------------------------------
	for i in range(0, len(tof), 5):
		values.append(tof[:][i:i+5])

	# fix char
	for i in values:
		for l in i:
			if l == range(0,len(i),3):
				res.append(l[:-1])
			else:
				res.append(l)

	# Database ---------------------------------------
	for i in range(len(keys)):
		dict[keys[i]] = tuple(values[i])
	return dict
	
def read_stats_file(filename):

	twoD = []
	each_line = []
	convertNum = []
	stats = []
	fullvalues = []
	values = []
	keys = []
	dict = {}

	# File ----------------------------------------
	file = open(filename,"r")
	file.readline()
	info = file.read()
	file.close()

	# MAIN -----------------------------------------
	all_line = info.replace('\n',',').split(',')[:-1]
	for i in range(len(all_line)):
		if all_line[i] != ',':
			each_line.append(all_line[i])

	# Integers ---------------------------------------
	for num in each_line:
		if num.isdigit():
			convertNum.append(int(num))
		else:
			convertNum.append(num)

	# 2d list ------------------------------------------
	for i in range(0, len(convertNum), 5):
		stats.append(convertNum[:][i:i+5])

	# Make two list, one for keys and one for values
	for i in stats:
		for k in range(len(i)):
			if k == 0:
				keys.append(i[k])
	for i in stats:
		for v in range(len(i)):
			if v != 0:
				fullvalues.append(i[v])

	# 2d values ---------------------------------------
	for i in range(0, len(fullvalues), 4):
		values.append(fullvalues[:][i:i+4])

	# Database ---------------------------------------
	for i in range(len(values)):
		dict[keys[i]] = tuple(values[i])
	return dict
	
def combine_databases(info_db, stats_db):

	keys = []
	values = []
	ids = []
	stats = []
	info = []
	xp = []
	twod_info = []
	twod_xp = []
	com = []
	dict = {}
	
	# info_db 
	for key,value in sorted(info_db.items()):
		keys.append(key)
		values.append(value)
	
	# stats_db
	for id,stat in stats_db.items():
		ids.append(id)
		stats.append(stat)
		
	for i in values:
		for type in i:
			info.append(type)
	for i in stats:
		for stat in i:
			xp.append(stat)

	# 2d info
	for i in range(0, len(info), 5):
		twod_info.append(info[:][i:i+5])
	# 2d stats
	for i in range(0, len(xp), 4):
		twod_xp.append(xp[:][i:i+4])

	for i in range(len(twod_info)):
		for z in reversed(twod_xp[i]):
			twod_info[i].insert(3,z)

	# Database ---------------------------------------
	for i in range(len(keys)):
		dict[keys[i]] = tuple(twod_info[i])
	return dict

def pokemon_by_types(db, types):
	dict = {}
	ndict = {}
	a = []
	for s in types:
		for k,v in db.items():
			if s in v:
				dict[k] = v # if type is a match
	for e,a in sorted(dict.items()):
		ndict[e] = a # sorting the dictionary
	return ndict
		
def team_hp(db,team):
	total = sum([])
	for s in team:
		if s in db:
			total +=(db.get(s)[3]) # add index to total
	return total # return sum of total
	
	
def pokemon_by_hp_defense(db, lowest_hp, lowest_defense):
	dict = {}
	for k,v in db.items():
		if v[3]>= lowest_hp and v[5] >= lowest_defense: # if requirements meet
			dict[k] = v # add them to dictionary
	return dict

def get_types(db):
	t = []
	s = []
	for v in db.values():
		t.append(v[1]) #
		t.append(v[2]) # add type 1 and 2 to a list
	for i in t:
		if i != None: # if list contains None remove it
			s.append(i)
	return sorted(set(s)) # sort the list and dont show doubles
	
def count_by_type(db,type):
	first_t = sum([0])
	sec_t = sum([0])
	
	for v in db.values():
		if v[1] == type and v[2] == None:
			first_t += 1 # add 1 if statement is true
	for v in db.values():
		if (v[1] == type or v[2] == type) and v[2] != None:
			sec_t += 1 # add 1 if statement is true
	total = [first_t,sec_t,first_t+sec_t] # make a list contains 3 items
	return tuple(total) # convert list to a tuple

def fastest_type(db):
	dict = {}
	tion = {}
	k = []
	d0 = {}
	if db == {}: # if its empty return None
		return None
	else:
		for k,v in db.items():
			for i in range(1,3): # indexing 1 and 2
				if v[i] in dict:
					dict[v[i]] = (dict[v[i]] + v[6]) # adding speed
				else:
					dict[v[i]] = v[6]
		for k,v in db.items():
			for i in range(1,3):
				if v[i] in tion: # indexing 1 and 2
					tion[v[i]] = tion[v[i]] + 1 # adding the occurrences
				else:
					tion[v[i]] = 1
		d3 = {x:float(dict[x])/tion[x] for x in tion} # dividing two dictionaries
		for k,v in d3.items():
			if k != None:
				d0[k] = v
		return sorted([key for key,val in d0.items() if val == max(d0.values())]) # sorting

		
def legendary_count_of_types(db):	
	dict = {}
	tion = {}
	diction = {}
	for i in range(1,3): # indexing 1 and 2
		for v in db.values():
			if v[8] == True:
				if ((v[i] and v[i]) in dict): # if 1 and 2 in dictionary
					dict[v[i]] = dict[v[i]] + 1
				elif (v[i] in dict): # if 1 in dictionary
					dict[v[i]] = dict[v[i]] + 1
				else: # value = 1
					dict[v[i]] = 1
					dict[v[i]] = 1
			elif v[8] == False:
				if ((v[i] and v[i]) in tion):# if 1 and 2 in dictionary
					tion[v[i]] = 0
				elif (v[i] in tion): # if 1 in dictionary
					tion[v[i]] = 0
				else: # value = 0
					tion[v[i]] = 0

	updated = tion.copy() # copy dictionary
	updated.update(dict) # uppdate dictionary
	for k,v in updated.items():
		if k != None: # if it has None, remove it
			diction[k] = v
				
	return diction

	

def show_of_strength_game(db, team1, team2):
	
	team1dict = {}
	team2dict = {}
	team1score = sum([])
	team2score = sum([])
	
	for i in team1:
		for k,v in db.items():
			if i == k:
				team1dict[i] = v[4] # team 1 attacks stats
	for i in team2:
		for k,v in db.items():
			if i == k:
				team2dict[i] = v[4] # team 2 attacks stats
	if len(team1) != len(team2): # unequal teams
		team1.append(([0,0,0,0,0])*(len(team2)-1))
	elif len(team2) != len(team1):
		team2.append(([0,0,0,0,0])*(len(team1)-1))
	else:
		for one in team1:
			for two in team2:
				if db[one][4] > db[two][4]: # team1 > team2
					team1score += 1
				elif db[one][4] < db[two][4]: # team1 < team2
					team2score += 1
	return team1score - team2score
	
	
def strongest_pokemon(db, type = None, generation = None):
	
	if (type == None) and (generation == None): # type == None and generation == None
		name = ['']
		num = [0]
		for k,v in db.items():
			if (v[3] + v[4] + v[5]) > num[0]: # is total of hp + attack + defense > 0
				num.remove(num[0]) # remove small number
				num.append(v[3] + v[4] + v[5]) # add high number
				name.append(k) # record name
				name.remove(name[0]) # delete old name
			elif (v[3] + v[4] + v [5]) == num[0]: # if stats are equal
				name.append(k) # add name
		return sorted(name)

	elif generation == None: # generation == None
		name = ['']
		num = [0]
		for k,v in db.items():
			if (v[1] == type) or (v[2] == type):
				if (v[3] + v[4] + v[5]) > num[0]:
					num.remove(num[0])
					num.append(v[3] + v[4] + v[5])
					name.append(k)
					name.remove(name[0])
				elif (v[3] + v[4] + v [5]) == num[0]:
					name.append(k)
	
		return sorted(name)
		
	else: # type and generation
		name = ['']
		num = [0]
		for k,v in db.items():
			if ((v[1] == type) or (v[2] == type)) and (v[7] == generation):
				if (v[3] + v[4] + v[5]) > num[0]:
					num.remove(num[0])
					num.append(v[3] + v[4] + v[5])
					name.append(k)
					name.remove(name[0])
				elif (v[3] + v[4] + v [5]) == num[0]:
					name.append(k)
	
		return sorted(name)

	 