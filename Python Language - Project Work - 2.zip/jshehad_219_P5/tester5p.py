# STUDENTS: TO USE:
# 
# The following command will test all test cases on your file:
# 
#   python3 <thisfile.py> <your_one_file.py>
# 
# 
# You can also limit the tester to only the functions you want tested.
# Just add as many functions as you want tested on to the command line at the end.
# Example: to only run tests associated with func1, func2, and func3, run this command:
# 
#   python3 <thisfile.py> <your_one_file.py> func1 func2 func3
# 


# INSTRUCTOR: TO PREPARE:
#  - add test cases to class AllTests. The test case functions' names must
# be precise - to test a function named foobar, the test must be named "test_foobar_#"
# where # may be any digits at the end, such as "test_foobar_13".
# - any extra-credit tests must be named "test_extra_credit_foobar_#"
# 
# - name all required definitions in REQUIRED_DEFNS. Do not include any unofficial 
#   helper functions. If you want to make helper definitions to use while testing,
#   those can also be added there for clarity.
# 
# to run on either a single file or all .py files in a folder (recursively):
#   python3 <thisfile.py> <your_one_file.py>
#   python3 <thisfile.py> <dir_of_files>
# 
# A work in progress by Mark Snyder, Oct. 2015.
#  Edited by Yutao Zhong, Spring 2016.
#  Edited by Raven Russell, Spring 2017.


import unittest
import shutil
import sys
import os
import os.path
import time

import importlib

############################################################################
############################################################################
# BEGIN SPECIALIZATION SECTION (the only part you need to modify beyond 
# adding new test cases).

# name all expected definitions; if present, their definition (with correct
# number of arguments) will be used; if not, a decoy complainer function
# will be used, and all tests on that function should fail.
	
REQUIRED_DEFNS = [	"read_info_file",
					"read_stats_file",
					"combine_databases",
					"pokemon_by_types",
					"pokemon_by_hp_defense",
					"get_types",
					"count_by_type",
					"fastest_type",
					"legendary_count_of_types",
					"team_hp",
					"show_of_strength_game",
					"strongest_pokemon",
					"top_team_with_best_attackers"
				 ]

extra_credit = [ 	"top_team_with_best_attackers"
				]
weight_required = 1.25
weight_extra_credit = 1

RENAMED_FILE = "student"

# Sample files and databases for testing

# info files and databases
# a single item
info_file1 = '''"ID","Name","Type 1","Type 2","Generation","Legendary"
1,"Bulbasaur","Grass","Poison",1,"FALSE"
'''
def info_db1():
	return {'Bulbasaur':(1,'Grass','Poison',1,False)}

# multiple items
info_file2 = '''"ID","Name","Type 1","Type 2","Generation","Legendary"
169,"Crobat","Poison","Flying",2,"FALSE"
6,"Charizard","Fire","Flying",1,"FALSE"
643,"Reshiram","Dragon","Fire",5,"TRUE"
'''
def info_db2():
	return {'Crobat':(169,'Poison','Flying',2,False),
			'Reshiram':(643,'Dragon','Fire',5,True),
			'Charizard':(6,'Fire','Flying',1,False)
			}


# multiple items; no 2nd type
info_file3 = '''"ID","Name","Type 1","Type 2","Generation","Legendary"
493,"Arceus","Normal","",4,"TRUE"
6,"Charizard","Fire","Flying",1,"FALSE"
4,"Charmander","Fire","",1,"FALSE"
169,"Crobat","Poison","Flying",2,"FALSE"
'''
def info_db3():
	return {'Charizard':(6,'Fire','Flying',1,False),
			'Arceus':(493,'Normal',None,4,True),
			'Charmander':(4,'Fire',None,1,False),
			'Crobat':(169,'Poison','Flying',2,False)
			}

# comma within name field
info_file4='''"ID","Name","Type 1","Type 2","Generation","Legendary"
1,"Bulbasaur","Grass","Poison",1,"FALSE"
6,"Charizard","Fire","Flying",1,"FALSE"
4,"Charmander","Fire","",1,"FALSE"
487,"Giratina, (Origin Form)","Ghost","Dragon",4,"TRUE"
169,"Crobat","Poison","Flying",2,"FALSE"
643,"Reshiram","Dragon","Fire",5,"TRUE"
641,"Tornadus, (Incarnate Form)","Flying","",5,"TRUE"
'''
def info_db4():
	return {'Bulbasaur':(1,'Grass','Poison',1,False),
			'Crobat':(169,'Poison','Flying',2,False),
			'Reshiram':(643,'Dragon','Fire',5,True),
			'Charizard':(6,'Fire','Flying',1,False),
			'Charmander':(4,'Fire',None,1,False),
			'Tornadus, (Incarnate Form)':(641,'Flying',None,5,True),
			'Giratina, (Origin Form)':(487,'Ghost','Dragon',4,True)
			}

info_file5='''"ID","Name","Type 1","Type 2","Generation","Legendary"
720,"HoopaHoopa, Confined","Psychic","Ghost",6,"TRUE"
1,"Bulbasaur","Grass","Poison",1,"FALSE"
681,"Aegislash, (Blade Form)","Steel","Ghost",6,"FALSE"
413,"Wormadam, Plant","Bug","Grass",4,"FALSE"
678,"Meowstic, Male","Psychic","",6,"FALSE"
'''

def info_db5():
	return {'HoopaHoopa, Confined':(720,'Psychic','Ghost',6,True),
			'Bulbasaur':(1,'Grass','Poison',1,False),
			'Aegislash, (Blade Form)':(681,'Steel','Ghost',6,False),
			'Wormadam, Plant':(413, 'Bug','Grass',4,False),
			'Meowstic, Male': (678,'Psychic',None,6,False)
			
			}
#############################################

#stat files and databases
stats_file1='''"ID","HP","Attack","Defense","Speed"
2,60,62,63,60
'''
def stats_db1():
	return {2:(60,62,63,60)}

stats_file2='''"ID","HP","Attack","Defense","Speed"
6,78,84,78,100
146,90,100,90,90
643,100,120,100,90
'''
def stats_db2():
	return {6:(78,84,78,100),
			146:(90,100,90,90),
			643:(100,120,100,90)}

stats_file3='''"ID","HP","Attack","Defense","Speed"
1,45,49,49,45
4,39,52,43,65
6,78,84,78,100
146,90,100,90,90
149,91,134,95,80
641,79,115,70,111
643,100,120,100,90
'''
def stats_db3():
	return {1:(45,49,49,45),
			4:(39,52,43,65),
			6:(78,84,78,100),
			146:(90,100,90,90),
			149:(91,134,95,80),
			641:(79,115,70,111),
			643:(100,120,100,90)
			}

def db1():
	return {'Bulbasaur':(1,'Grass','Poison',45,49,49,45,1,False),
			'Reshiram':(643,'Dragon','Fire',100,120,100,90,5,True),
			'Charizard':(6,'Fire','Flying',78,84,78,100, 1,False),
			'Charmander':(4,'Fire',None,39,52,43,65,1,False),
			'Tornadus, (Incarnate Form)':(641,'Flying',None,79,115,70,111,5,True)
			}

def db2():
	return {'Torkoal':(324,'Fire',None,70,85,140,20,3,False),
			'Pansear':(513,'Fire',None,50,53,48,64,5,False),
			'Charmander':(4,'Fire',None,39,52,43,65,1,False),
			'Entei': (244,'Fire',None,115,115,85,100,2,True)
			}
			
def db3():
	return{'Charizard':(6,'Fire','Flying',78,84,78,100, 1,False),
			'Moltres':(146,'Fire','Flying',90,100,90,90,1,True),
			'Ho-oh':(250,'Flying','Fire',106,130,90,90,2,True)
			}

def db4():
	return {'Bulbasaur':(1,'Grass','Poison',45,49,49,45,1,False),
			'Reshiram':(643,'Dragon','Fire',100,120,100,90,5,True),
			'Entei': (244,'Fire',None,115,115,85,100,2,True),
			'Charmander':(4,'Fire',None,39,52,43,65,1,False),
			'Tornadus, (Incarnate Form)':(641,'Flying',None,79,115,70,111,5,True),
			'Ho-oh':(250,'Flying','Fire',106,130,90,90,2,True),
			'Primeape': (57, 'Fighting', None, 65, 105, 60, 95, 1, False),
 			'Mantyke': (458, 'Water', 'Flying', 45, 20, 50, 50, 4, False),
			'Lombre': (271, 'Water', 'Grass', 60, 50, 50, 50, 3, False),
			'Virizion': (640, 'Grass', 'Fighting', 91, 90, 72, 108, 5, True),
			'Volcanion': (721, 'Fire', 'Water', 80, 110, 120, 70, 6, True),
			'Arcanine': (59, 'Fire', None, 90, 110, 80, 95, 1, False)
			}
			
	
def db5():
	return {
			'Charmander': (4, 'Fire', None, 39, 52, 42, 65, 1, False),
 			'Trapinch': (328, 'Ground', None, 45, 100, 66, 10, 3, False),
 			'Charizard': (6, 'Fire', 'Flying', 78, 84, 78, 100, 1, False),
 			'Vibrava': (329, 'Ground', 'Dragon', 50, 70, 50, 70, 3, False),
			'Charmeleon': (5, 'Fire', None, 58, 64, 58, 80, 1, False),
 			'Camerupt': (323, 'Fire', 'Ground', 70, 100, 70, 40, 3, False),
			'Drifloon': (425, 'Ghost', 'Flying', 90, 50, 34, 70, 4, False)
	}
	
def db6():
	return {
			'A': (1, 'Fire','Rock', 10, 20, 30, 40, 1, True),
			'B': (1, 'Water',None, 10, 20, 30, 80, 2, False),
			'C': (1, 'Ground','Fire', 10, 20, 30, 55, 3, True),
			'D': (1, 'Water','Rock', 10, 20, 30, 37, 4, False),
			'E': (1, 'Fire',None, 10, 20, 30, 102, 5, True),
			'F': (1, 'Water',None, 10, 20, 30, 80, 6, False),
			
	}

def db7():
	return {
			'A': (1, 'Fire','Grass', 10, 20, 30, 66, 1, True),
			'B': (1, 'Water','Ice', 10, 20, 30, 66, 2, False),
			'C': (1, 'Grass','Dragon', 10, 20, 30, 66, 3, True),
			'D': (1, 'Dragon','Water', 10, 20, 30, 66, 4, False),
			'E': (1, 'Ghost','Fire', 10, 20, 30, 66, 5, True),
			'F': (1, 'Ice','Ghost', 10, 20, 30, 66, 6, False),
	}

def db8():
	return {
			'F': (1, 'Water',None, 17, 15, 20, 80, 6, False),	
			'A': (1, 'Fire','Rock', 10, 20, 30, 40, 1, True),
			'C': (1, 'Ground','Fire', 15, 15, 30, 55, 3, True),
			'D': (1, 'Water','Rock', 50, 5, 5, 37, 4, False),
			'B': (1, 'Water',None, 20, 10, 10, 80, 2, False),
			'E': (1, 'Fire',None, 40, 15, 5, 102, 5, True),
	}

DATAFILE = "file_for_testing.csv"
def put_file(s):
	f = open(DATAFILE,"w")
	f.write(s)
	f.close()

# END SPECIALIZATION SECTION
############################################################################
############################################################################



# enter batch mode by giving a directory to work on.
BATCH_MODE = (sys.argv[1] in ["."] or os.path.isdir(sys.argv[1]))

# This class contains multiple "unit tests" that each check
# various inputs to specific functions, checking that we get
# the correct behavior (output value) from completing the call.
class AllTests (unittest.TestCase):
	
	############################################################
	
	def test_read_info_file_01 (self): 
		put_file(info_file1)
		self.assertEqual(read_info_file(DATAFILE),info_db1())

	def test_read_info_file_02 (self): 
		put_file(info_file2)
		self.assertEqual(read_info_file(DATAFILE),info_db2())

	def test_read_info_file_03 (self): 
		put_file(info_file3)
		self.assertEqual(read_info_file(DATAFILE),info_db3())

	def test_read_info_file_04 (self): #name with comma inside
		put_file(info_file4)
		self.assertEqual(read_info_file(DATAFILE),info_db4())

	def test_read_info_file_05 (self): #name with comma inside
		put_file(info_file5)
		self.assertEqual(read_info_file(DATAFILE),info_db5())
	
	############################################################
	
	def test_read_stats_file_01 (self): 
		put_file(stats_file1)
		self.assertEqual(read_stats_file(DATAFILE),stats_db1())

	def test_read_stats_file_02 (self): 
		put_file(stats_file2)
		self.assertEqual(read_stats_file(DATAFILE),stats_db2())

	def test_read_stats_file_03 (self): 
		put_file(stats_file3)
		self.assertEqual(read_stats_file(DATAFILE),stats_db3())
	
	############################################################

	def test_combine_databases_01 (self):
		stats_db = {1:(45,49,49,45)}
		info_db = {'Bulbasaur':(1,'Grass','Poison',1,False)}
		combined = combine_databases(info_db, stats_db)
		self.assertEqual(combined, {'Bulbasaur':(1,'Grass','Poison',45,49,49,45,1,False)})
		
	def test_combine_databases_02 (self): #original databases not modified
		stats_db = {1:(45,49,49,45)}
		info_db = {'Bulbasaur':(1,'Grass','Poison',1,False)}
		combined = combine_databases(info_db, stats_db)
		self.assertEqual(stats_db,{1:(45,49,49,45)})
		self.assertEqual(info_db,{'Bulbasaur':(1,'Grass','Poison',1,False)})
	
	def test_combine_databases_03 (self): # item s from only one db discarded
		combined = combine_databases(info_db2(), stats_db2())
		self.assertEqual(combined, {'Reshiram':(643,'Dragon','Fire',100,120,100,90,5,True),
									'Charizard':(6,'Fire','Flying',78,84,78,100,1,False)})
										
	def test_combine_databases_04 (self): # items from only one db discarded
		combined = combine_databases(info_db4(), stats_db3())
		self.assertEqual(combined, db1())

	def test_combine_databases_05 (self): # items from only one db discarded
		combined = combine_databases(info_db5(), stats_db2())
		self.assertEqual(combined, {})
		
	############################################################
	
	def test_pokemon_by_types_01 (self):	# one pokemon
		db = db1()
		self.assertEqual(pokemon_by_types(db,["Poison"]), 
						{'Bulbasaur':(1,'Grass','Poison',45,49,49,45,1,False)})
		self.assertEqual(db, db1()) #original database not changed
		
		
	def test_pokemon_by_types_02 (self):	# multiple pokemon of the same type
		self.assertEqual(pokemon_by_types(db1(),["Fire"]), 
						{'Reshiram':(643,'Dragon','Fire',100,120,100,90,5,True),
						'Charizard':(6,'Fire','Flying',78,84,78,100, 1,False),
						'Charmander':(4,'Fire',None,39,52,43,65,1,False)})

	def test_pokemon_by_types_03 (self):	# multiple types
		self.assertEqual(pokemon_by_types(db1(),["Poison","Dragon"]), 
						{'Reshiram':(643,'Dragon','Fire',100,120,100,90,5,True),
						'Bulbasaur':(1,'Grass','Poison',45,49,49,45,1,False)})

	def test_pokemon_by_types_04 (self):	# one pokemon match multiple types  
		self.assertEqual(pokemon_by_types(db1(),["Poison","Grass"]), 
						{'Bulbasaur':(1,'Grass','Poison',45,49,49,45,1,False)})

	def test_pokemon_by_types_05 (self):	# no match
		self.assertEqual(pokemon_by_types(db1(),["Dark","Water"]), {})
	
	def test_pokemon_by_types_06 (self):	# one pokemon match multiple types  
		self.assertEqual(pokemon_by_types(db1(),["Fire","Flying","Grass"]),db1())

	############################################################
	
	def test_pokemon_by_hp_defense_01 (self):	# one pokemon
		db = db1()
		self.assertEqual(pokemon_by_hp_defense(db,100,100), 
						{'Reshiram':(643,'Dragon','Fire',100,120,100,90,5,True)})
		self.assertEqual(db, db1()) #original database not changed

	def test_pokemon_by_hp_defense_02 (self):	# multiple pokemon
		self.assertEqual(pokemon_by_hp_defense(db1(),30,72), 
						{'Reshiram':(643,'Dragon','Fire',100,120,100,90,5,True),
						'Charizard':(6,'Fire','Flying',78,84,78,100, 1,False)})

	def test_pokemon_by_hp_defense_03 (self):	# multiple pokemon
		self.assertEqual(pokemon_by_hp_defense(db1(),50,40), 
						{'Reshiram':(643,'Dragon','Fire',100,120,100,90,5,True),
						'Charizard':(6,'Fire','Flying',78,84,78,100, 1,False),
						'Tornadus, (Incarnate Form)':(641,'Flying',None,79,115,70,111,5,True)})

	def test_pokemon_by_hp_defense_04 (self):	# no match
		self.assertEqual(pokemon_by_hp_defense(db1(),90,120), {})

	############################################################
		
	def test_get_types_01 (self):	# single pokemon, 2 types
		db ={'Bulbasaur':(1,'Grass','Poison',45,49,49,45,1,False)}
		self.assertEqual(get_types(db),['Grass','Poison']) 

	def test_get_types_02 (self):	# multiple pokemon, one type
		self.assertEqual(get_types(db2()),['Fire']) 

	def test_get_types_03 (self):	# multiple types
		self.assertEqual(get_types(db3()),['Fire','Flying']) 

	def test_get_types_04 (self):	# multiple types
		self.assertEqual(get_types(db1()),['Dragon','Fire','Flying','Grass','Poison']) 

	def test_get_types_05 (self):	# empty dictionary returns empty list
		self.assertEqual(get_types({}),[]) 

	############################################################
		
	def test_count_by_type_01 (self):	# single pokemon dual type
		db ={'Bulbasaur':(1,'Grass','Poison',45,49,49,45,1,False)}
		self.assertEqual(count_by_type(db,'Grass'),(0,1,1)) 

	def test_count_by_type_02 (self):	# no such type
		self.assertEqual(count_by_type(db2(),'Grass'),(0,0,0))
		 
	def test_count_by_type_03 (self):	# multiple pokemon single type
		self.assertEqual(count_by_type(db2(),'Fire'),(4,0,4))

	def test_count_by_type_04 (self):	# multiple pokemon dual type
		self.assertEqual(count_by_type(db3(),'Flying'),(0,3,3))

	def test_count_by_type_05 (self):	# mixed
		self.assertEqual(count_by_type(db1(),'Fire'),(1,2,3))


	############################################################
		
	def test_fastest_type_01 (self):	# single type
		db ={'Primeape': (57, 'Fighting', None, 65, 105, 60, 95, 1, False)}
		self.assertEqual(fastest_type(db),['Fighting']) 

	def test_fastest_type_02 (self):	# single pokemon dual type
		db ={'Bulbasaur':(1,'Grass','Poison',45,49,49,45,1,False)}
		self.assertEqual(fastest_type(db),['Grass','Poison']) 

	def test_fastest_type_03 (self):	# multiple types, single winner
		self.assertEqual(fastest_type(db1()),['Flying']) 

	def test_fastest_type_04 (self):	# empty dictionary returns None
		self.assertEqual(fastest_type({}),None) 

	def test_fastest_type_05 (self):	# tie: multiple winners
		self.assertEqual(fastest_type(db6()),['Fire','Water']) 

	def test_fastest_type_06 (self):	# tie: multiple winners
		self.assertEqual(fastest_type(db7()),['Dragon','Fire','Ghost','Grass','Ice','Water']) 

	############################################################

	
	def test_legendary_count_of_types_01 (self):	# single pokemon, single type, not legendary
		db ={'Torkoal':(324,'Fire',None,70,85,140,20,3,False)}
		self.assertEqual(legendary_count_of_types(db),{'Fire':0})

	def test_legendary_count_of_types_02 (self):	# multiple pokemon, single type
		self.assertEqual(legendary_count_of_types(db2()),{'Fire':1})

	def test_legendary_count_of_types_03 (self):	# multiple pokemon, multiple types
		self.assertEqual(legendary_count_of_types(db3()),{'Fire':2, 'Flying':2})

	def test_legendary_count_of_types_04 (self):	# lots of types
		self.assertEqual(legendary_count_of_types(db4()),
						{'Grass':1, 'Fire':4, 'Flying':2, 'Poison':0, 'Dragon': 1, 'Water':1, 'Fighting':1})

	def test_legendary_count_of_types_05 (self):	# empty dictionary returns empty dictionary
		self.assertEqual(legendary_count_of_types({}),{})

	############################################################
	
	def test_team_hp_01 (self): #single pokemon
		self.assertEqual(team_hp(db4(),['Volcanion']),80)

	def test_team_hp_02 (self): #multiple pokemons
		self.assertEqual(team_hp(db4(),['Bulbasaur','Volcanion','Primeape','Lombre']),250)


	def test_team_hp_03 (self): #multiple pokemons
		self.assertEqual(team_hp(db5(),['Charmander','Charizard','Charmeleon']),175)

	def test_team_hp_04 (self): #no pokemon
		self.assertEqual(team_hp(db4(),[]),0)
		
	############################################################

	def test_show_of_strength_game_01 (self): #single pokemon each team, team1 wins
		self.assertEqual(show_of_strength_game(db4(),['Volcanion'],['Bulbasaur']),1)

	def test_show_of_strength_game_02 (self): #single pokemon each team, tie
		self.assertEqual(show_of_strength_game(db4(),['Volcanion'],['Arcanine']),0)

	def test_show_of_strength_game_03 (self): #single pokemon each team, team2 wins
		self.assertEqual(show_of_strength_game(db4(),['Charmander'],['Volcanion']),-1)

	def test_show_of_strength_game_04 (self): #same num pokemon each team, team1 win 3, team2 win 1
		self.assertEqual(show_of_strength_game(db4(),['Volcanion','Bulbasaur','Reshiram','Entei'],
							['Bulbasaur','Arcanine','Lombre','Virizion']),2)

	def test_show_of_strength_game_05 (self): #same num pokemon each team, team1 win 2, team2 win 2
		self.assertEqual(show_of_strength_game(db4(),['Volcanion','Bulbasaur','Reshiram','Entei'],
							['Bulbasaur','Arcanine','Lombre','Ho-oh']),0)

	def test_show_of_strength_game_06 (self): #same num pokemon each team, team1 win 0, team2 win 4, tie 1
		self.assertEqual(show_of_strength_game(db4(),['Volcanion','Charmander','Arcanine','Mantyke','Bulbasaur'],
							['Entei','Primeape','Volcanion','Lombre','Ho-oh']),-4)

	def test_show_of_strength_game_07 (self): #teams of different sizes, team1 win 2, team2 win 2
		self.assertEqual(show_of_strength_game(db4(),['Volcanion','Charmander','Mantyke','Bulbasaur'],
							['Entei','Primeape']),0)

	def test_show_of_strength_game_08 (self): #teams of different sizes, team1 win 1, team2 win 2, tie 1
		self.assertEqual(show_of_strength_game(db4(),['Volcanion','Arcanine','Charmander'],
							['Virizion','Volcanion','Primeape','Entei']),-1)

	############################################################

	def test_strongest_pokemon_01 (self): #single pokemon 
		db = {'Bulbasaur':(1,'Grass','Poison',45,49,49,45,1,False)}
		self.assertEqual(strongest_pokemon(db),['Bulbasaur'])
		
	def test_strongest_pokemon_02 (self): #no restriction 
		self.assertEqual(strongest_pokemon(db4()),['Ho-oh'])

	def test_strongest_pokemon_03 (self): #only certain type 
		self.assertEqual(strongest_pokemon(db4(),'Water'),['Volcanion'])

	def test_strongest_pokemon_04 (self): #only certain generation
		self.assertEqual(strongest_pokemon(db4(),generation=5),['Reshiram'])

	def test_strongest_pokemon_05 (self): #restricting both type and generation
		self.assertEqual(strongest_pokemon(db4(),"Grass",1),['Bulbasaur'])
		
	def test_strongest_pokemon_06 (self): #tie
		self.assertEqual(strongest_pokemon(db5()),['Camerupt', 'Charizard'])

	def test_strongest_pokemon_07 (self): #no pokemon satisfy the condition
		self.assertEqual(strongest_pokemon(db5(),"Fighting"),None)

	def test_strongest_pokemon_08 (self): #more pokemon tie
		self.assertEqual(strongest_pokemon(db8()),['A','C','D','E'])

	############################################################
	
	def test_extra_credit_top_team_with_best_attackers_01 (self): #team of 3
		self.assertEqual(top_team_with_best_attackers(db1(),3), 
				['Reshiram','Tornadus, (Incarnate Form)','Charizard'])	  

	def test_extra_credit_top_team_with_best_attackers_02 (self): # ask for 6, only have 5
		self.assertEqual(top_team_with_best_attackers(db1()), 
				['Reshiram','Tornadus, (Incarnate Form)','Charizard','Charmander','Bulbasaur'])	  

	def test_extra_credit_top_team_with_best_attackers_03 (self): #tie
		self.assertEqual(top_team_with_best_attackers(db4(),size=7), 
			['Ho-oh','Reshiram','Entei','Tornadus, (Incarnate Form)','Arcanine','Volcanion','Primeape'])

	def test_extra_credit_top_team_with_best_attackers_04 (self): # tie
		self.assertEqual(top_team_with_best_attackers(db4(),5), 
			['Ho-oh','Reshiram','Entei','Tornadus, (Incarnate Form)','Arcanine'])

	def test_extra_credit_top_team_with_best_attackers_05 (self): # rank all
		self.assertEqual(top_team_with_best_attackers(db4(),len(db4())), 
			['Ho-oh','Reshiram','Entei','Tornadus, (Incarnate Form)','Arcanine','Volcanion','Primeape',
			'Virizion','Charmander','Lombre','Bulbasaur','Mantyke'])


# This class digs through AllTests, counts and builds all the tests,
# so that we have an entire test suite that can be run as a group.
class TheTestSuite (unittest.TestSuite):
	# constructor.
	def __init__(self,wants):
		# find all methods that begin with "test".
		fs = []
		for w in wants:
			for func in AllTests.__dict__:
				# append regular tests
				# drop any digits from the end of str(func).
				dropnum = str(func)
				while dropnum[-1] in "1234567890":
					dropnum = dropnum[:-1]
				
				if dropnum==("test_"+w+"_") and (not (dropnum==("test_extra_credit_"+w+"_"))):
					fs.append(AllTests(str(func)))
				if dropnum==("test_extra_credit_"+w+"_") and not BATCH_MODE:
					fs.append(AllTests(str(func)))
		
		# call parent class's constructor.
		unittest.TestSuite.__init__(self,fs)

class TheExtraCreditTestSuite (unittest.TestSuite):
		# constructor.
		def __init__(self,wants):
			# find all methods that begin with "test_extra_credit_".
			fs = []
			for w in wants:
				for func in AllTests.__dict__:
					if BATCH_MODE and str(func).startswith("test_extra_credit_"+w):
						fs.append(AllTests(str(func)))
		
			# call parent class's constructor.
			unittest.TestSuite.__init__(self,fs)

# all (non-directory) file names, regardless of folder depth,
# under the given directory 'dir'.
def files_list(dir):
	info = os.walk(dir)
	filenames = []
	for (dirpath,dirnames,filez) in info:
#		print(dirpath,dirnames,filez)
		if dirpath==".":
			continue
		for file in filez:
			filenames.append(os.path.join(dirpath,file))
#		print(dirpath,dirnames,filez,"\n")
#		filenames.extend(os.path.join(dirpath, filez))
	return filenames

def main():
	if len(sys.argv)<2:
		raise Exception("needed student's file name as command-line argument:"\
			+"\n\t\"python3 tester4L.py gmason76_2xx_L4.py\"")
	want_all = len(sys.argv) <=2
	wants = []
	
	# remove batch_mode signifiers from want-candidates.
	want_candidates = sys.argv[2:]
	for i in range(len(want_candidates)-1,-1,-1):
		if want_candidates[i] in ['.'] or os.path.isdir(want_candidates[i]):
			del want_candidates[i]
	
	if not want_all:
		#print("args: ",sys.argv)
		for w in want_candidates:
			if w in REQUIRED_DEFNS:
				wants.append(w)
			else:
				raise Exception("asked to limit testing to unknown function '%s'."%w)
	else:
		wants = REQUIRED_DEFNS

	if not BATCH_MODE:
		#time.sleep(1) #make sure there is a time gap between last check run and this one
		#run_file(sys.argv[1],wants)
		if not want_all:
			run_file(sys.argv[1],wants)
		else:
			if len(extra_credit) == 0:
				(tag, passed1,tried1,ec) = run_file(sys.argv[1],wants)

				print('='*40)
				print("\nTest cases: %d/%d passed" % (passed1,tried1) )
				print("Score based on test cases: %.2f/100" % (passed1*weight_required))
			
			else:	
				print("Testing required functions:")			
				(tag, passed1,tried1,ec) = run_file(sys.argv[1],wants[:-len(extra_credit)])
				if passed1 == None:
					return

				print("\nTesting extra credit functions:")			
				(tag, passed2,tried2,ec) = run_file(sys.argv[1],extra_credit)
				if passed2!= None:
					print('='*40)
					print("Required test cases: %d/%d passed" % (passed1,tried1) )
					print("Extra credit test cases: %d/%d passed" % (passed2, tried2))
					print("Score based on test cases: %.2f (%.2f+%d) " % (passed1*weight_required+passed2*weight_extra_credit, 
														passed1*weight_required, passed2*weight_extra_credit))

				else:
					print('='*40)
					print("Required test cases: %d/%d passed" % (passed1,tried1) )
					print("Extra credit test cases: 0 passed")
					print("Score based on test cases: %.2f (%.2f+0) " % (passed1*weight_required, 
														passed1*weight_required))

	else:
		filenames = files_list(sys.argv[1])
	
# 		print(filenames)
	
		results = []
		for filename in filenames:
			try:
				print("\n\n\nRUNNING: "+filename)
				(tag, passed,tried,ec) = run_file(filename,wants)
				results.append((tag,passed,tried,ec))
			except SyntaxError as e:
				results.append((filename+"_SYNTAX_ERROR",0,1))	
			except NameError as e:
				results.append((filename+"_Name_ERROR",0,1))	
			except ValueError as e:
				results.append(filename+"_VALUE_ERROR",0,1)
			except TypeError as e:
				results.append(filename+"_TYPE_ERROR",0,1)
			except ImportError as e:
				results.append((filename+"_IMPORT_ERROR_TRY_AGAIN	",0,1))	
			except Exception as e:
				results.append(filename+str(e.__reduce__()[0]),0,1)
			
		print("\n\n\nGRAND RESULTS:\n")
		for (tag, passed, tried, ec) in results:
			print(("%.0f%%  (%d/%d, %dEC) - " % (passed/tried*100 + ec, passed, tried, ec))+tag)

def try_copy(filename1, filename2, numTries):
	have_copy = False
	i = 0
	while (not have_copy) and (i < numTries):
		try:
			# move the student's code to a valid file.
			shutil.copy(filename1,filename2)
			
			# wait for file I/O to catch up...
			if(not wait_for_access(filename2, numTries)):
				return False
				
			have_copy = True
		except PermissionError:
			print("Trying to copy "+filename1+", may be locked...")
			i += 1
			time.sleep(1)
	
	if(i == numTries):
		return False
	return True
			
def try_remove(filename, numTries):
	removed = False
	i = 0
	while os.path.exists(filename) and (not removed) and (i < numTries):
		try:
			os.remove(filename)
			removed = True
		except OSError:
			print("Trying to remove "+filename+", may be locked...")
			i += 1
			time.sleep(1)
	if(i == numTries):
		return False
	return True

def wait_for_access(filename, numTries):
	i = 0
	while (not os.path.exists(filename) or not os.access(filename, os.R_OK)) and i < numTries:
		print("Waiting for access to "+filename+", may be locked...")
		time.sleep(1)
		i += 1
	if(i == numTries):
		return False
	return True

# this will group all the tests together, prepare them as 
# a test suite, and run them.
def run_file(filename,wants=[]):
	if(not try_copy(filename,"student.py", 5)):
		print("Failed to copy " + filename + " to student.py.")
		quit()
	
	# import student's code, and *only* copy over the expected functions
	# for later use.
	import imp
	count = 0
	while True:
		try:
			import student
			imp.reload(student)
			break
		except ImportError as e:
			print("import error getting student.. trying again. "+os.getcwd(), os.path.exists("student.py"))
			time.sleep(0.5)
			count+=1
			if count>3:
				raise ImportError("too many attempts at importing!")
		except SyntaxError as e:
			print("SyntaxError in "+filename+":\n"+str(e))
			print("Run your file without the tester to see the details")
			return((filename+"_SYNTAX_ERROR",None,1,0))
		except NameError as e:
			print("NameError in "+filename+":\n"+str(e))
			print("Run your file without the tester to see the details")
			return((filename+"_Name_ERROR",None,1,0))	
		except ValueError as e:
			print("ValueError in "+filename+":\n"+str(e))
			print("Run your file without the tester to see the details")
			return(filename+"_VALUE_ERROR",None,1,0)
		except TypeError as e:
			print("TypeError in "+filename+":\n"+str(e))
			print("Run your file without the tester to see the details")
			return(filename+"_TYPE_ERROR",None,1,0)
		except ImportError as e:			
			print("ImportError in "+filename+":\n"+str(e))
			print("Run your file without the tester to see the details or try again")
			return((filename+"_IMPORT_ERROR_TRY_AGAIN	",None,1,0))	
		except Exception as e:
			print("Exception in loading"+filename+":\n"+str(e))
			print("Run your file without the tester to see the details")
			return(filename+str(e.__reduce__()[0]),None,1,0)
		#except Exception as e:
		#	print("didn't get to import student yet... " + e)
	# but we want to re-load this between student runs...
	# the imp module helps us force this reload.s
	
	import student
	imp.reload(student)
	
	# make a global for each expected definition.
	def decoy(name):
		return (lambda x: "<no '%s' definition found>" % name)
		
	for fn in wants:#REQUIRED_DEFNS
		globals()[fn] = decoy(fn)
		try:
			globals()[fn] = getattr(student,fn)
		except:
			print("\nNO DEFINITION FOR '%s'." % fn)	
			if fn in extra_credit:
				return ("no extra",0,0,0)
	
	# create an object that can run tests.
	runner1 = unittest.TextTestRunner()
	
	# define the suite of tests that should be run.
	suite1 = TheTestSuite(wants)
	
	# let the runner run the suite of tests.
	ans = runner1.run(suite1)
	num_errors   = len(ans.__dict__['errors'])
	num_failures = len(ans.__dict__['failures'])
	num_tests    = ans.__dict__['testsRun']
	num_passed   = num_tests - num_errors - num_failures
	# print(ans)

	if BATCH_MODE:
		# do the same for the extra credit.
		runnerEC = unittest.TextTestRunner()
		suiteEC = TheExtraCreditTestSuite(wants)
		ansEC = runnerEC.run(suiteEC)
		num_errorsEC   = len(ansEC.__dict__['errors'])
		num_failuresEC = len(ansEC.__dict__['failures'])
		num_testsEC    = ansEC.__dict__['testsRun']
		num_passedEC   = num_testsEC - num_errorsEC - num_failuresEC
		print(ansEC)
	else:
		num_passedEC = 0
	
	# remove our temporary files.
	if os.path.exists("__pycache__"):
		shutil.rmtree("__pycache__", ignore_errors=True)
	if(not try_remove("student.py", 5)):
		print("Failed to copy " + filename + " to student.py.")
	
	tag = ".".join(filename.split(".")[:-1])
	return (tag, num_passed, num_tests,num_passedEC)

# this determines if we were imported (not __main__) or not;
# when we are the one file being run, perform the tests! :)
if __name__ == "__main__":
	main()
