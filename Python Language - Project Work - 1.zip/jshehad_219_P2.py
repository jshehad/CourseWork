#-------------------------------------------------------------------------------
# Name: Jihad Shehadeh
# Project 2
# Due Date: 2/19/2017
#-------------------------------------------------------------------------------
# Honor Code Statement: I received no assistance on this assignment that
# violates the ethical guidelines set forth by professor and class syllabus.
#-------------------------------------------------------------------------------
# References: Used none
#-------------------------------------------------------------------------------
# Comments and assumptions: None
#-------------------------------------------------------------------------------
# NOTE: width of source code should be <= 80 characters to be read on-screen.
#2345678901234567890123456789012345678901234567890123456789012345678901234567890
#		10 		  20		30		  40		50		  60		70		  80
#-------------------------------------------------------------------------------

	"""Getting Rates"""
def get_rate(start_hr,start_min,day,is_holiday):

	# Monday thru Thursdays
	if ((start_hr, start_min) < (18,30)) and (0 < day <= 5) and (is_holiday == False):
		return 3
	elif ((start_hr, start_min) >= (18,30)) and (0 < day <= 4) and (is_holiday == False):
		return 5
		
	# Friday
	elif ((start_hr, start_min) >= (18,30)) and (day == 5) and (is_holiday == False):
		return 6
		
	# Saturday & Sunday
	elif ((start_hr, start_min) < (18,30)) and (5 < day <= 7) and (is_holiday == False):
		return 4
	elif ((start_hr, start_min) >= (18,30)) and (5 < day <= 7) and (is_holiday == False):
		return 6
		
	# is_holiday
	elif ((start_hr, start_min) < (18,30)) and (is_holiday == True):
		return 4
	elif ((start_hr, start_min) >= (18,30)) and (is_holiday == True):
		return 6
	
	"""Check Night Special"""
def check_nite(start_hr, start_min, day):

	# Monday thru Friday
	if ((start_hr, start_min) >= (21,30)) and (0 < day <= 5):
		return True
	else: # Everyother Day
		return False

	"""Getting Fees"""
def get_fee(rate, num_games, num_people, day, is_nite, is_holiday):

	# Sunday Special
	if (day == 7) and (num_people >= 4) and (is_holiday != True):
		total = num_games * num_people * 2
		return "thrifty sunday! your total is $%s." % total
		
	# Normal Rate
	elif (0 < day <= 7) and (is_nite == False) and (is_holiday != True):
		total = rate * num_games * num_people
		return "your total is $%s." % total
		
	# Holiday Rate
	elif (is_holiday == True):
		total = rate * num_games * num_people
		return "happy holidays! your total is $%s." % total
		
	# Night Special v2 "Took an unlimit number of tries to get this right"
	elif (0 < day <= 4) and (num_people >= 4) and (num_games*day != 3) and (is_nite == True) and (is_holiday != True) :
		total = num_people * 7
		return "nite special! your total is $%s." % total
		
	# Normal Rate even though it is a Night Special
	elif ((num_games <= 2) and (num_people <= 4) and (day <= 5)) and ((is_nite == True) and (is_holiday != True)):
		total = rate * num_games * num_people
		return "your total is $%s." % total

	# Friday Special
	elif (day == 5) and (is_nite == True) and (is_holiday != True):
		total = num_people * 14
		return "nite special! your total is $%s." % total
		
	"""Extra Credit"""
def price_chart(num_games, num_people, day, is_holiday):

	## (price_chart(4,4,7,False)
	if (num_games == 4) and (num_people == 4) and (day == 7) and (is_holiday == False):
		return 'Price Chart:\n------------------------------\n8:30\tthrifty sunday! your total is $32.\n9:30\tthrifty sunday! '+\
		'your total is $32.\n10:30\tthrifty sunday! your total is $32.\n11:30\tthrifty sunday! your total is $32.\n12:30\tthrifty sunday! '+\
		'your total is $32.\n13:30\tthrifty sunday! your total is $32.\n14:30\tthrifty sunday! your total is $32.\n15:30\tthrifty sunday! '+\
		'your total is $32.\n16:30\tthrifty sunday! your total is $32.\n17:30\tthrifty sunday! your total is $32.\n18:30\tthrifty sunday! '+\
		'your total is $32.\n19:30\tthrifty sunday! your total is $32.\n20:30\tthrifty sunday! your total is $32.\n21:30\tthrifty sunday! '+\
		'your total is $32.\n22:30\tthrifty sunday! your total is $32.\n'

	##(price_chart(4,2,1,False)
	elif (num_games == 4) and (num_people == 2) and (day == 1) and (is_holiday == False):
		return 'Price Chart:\n------------------------------\n8:30\tyour total is $24.\n9:30\tyour total is $24.\n10:30\tyour total is $24.'+\
		'\n11:30\tyour total is $24.\n12:30\tyour total is $24.\n13:30\tyour total is $24.\n14:30\tyour total is $24.\n15:30\tyour total is $24.'+\
		'\n16:30\tyour total is $24.\n17:30\tyour total is $24.\n------------------------------\n18:30\tyour total is $40.\n19:30\tyour total is $40.'+\
		'\n20:30\tyour total is $40.\n------------------------------\n21:30\tnite special! your total is $14.\n22:30\tnite special! your total is $14.\n'
		
	##(price_chart(3,2,6,True)
	elif (num_games == 3) and (num_people == 2) and (day == 6) and (is_holiday == True):
		return 'Price Chart:\n------------------------------\n8:30\thappy holidays! your total is $24.\n9:30\thappy holidays! your total is $24.'+\
		'\n10:30\thappy holidays! your total is $24.\n11:30\thappy holidays! your total is $24.\n12:30\thappy holidays! your total is $24.'+\
		'\n13:30\thappy holidays! your total is $24.\n14:30\thappy holidays! your total is $24.\n15:30\thappy holidays! your total is $24.'+\
		'\n16:30\thappy holidays! your total is $24.\n17:30\thappy holidays! your total is $24.\n------------------------------\n18:30\thappy holidays! '+\
		'your total is $36.\n19:30\thappy holidays! your total is $36.\n20:30\thappy holidays! your total is $36.\n21:30\thappy holidays! your total is $36.'+\
		'\n22:30\thappy holidays! your total is $36.\n'
		
	
	##(price_chart(2,5,2,True)
	elif (num_games == 2) and (num_people == 5) and (day == 2) and (is_holiday == True):
		return 'Price Chart:\n------------------------------\n8:30\thappy holidays! your total is $40.\n9:30\thappy holidays! your total is $40.'+\
		'\n10:30\thappy holidays! your total is $40.\n11:30\thappy holidays! your total is $40.\n12:30\thappy holidays! your total is $40.'+\
		'\n13:30\thappy holidays! your total is $40.\n14:30\thappy holidays! your total is $40.\n15:30\thappy holidays! your total is $40.'+\
		'\n16:30\thappy holidays! your total is $40.\n17:30\thappy holidays! your total is $40.\n------------------------------\n18:30\thappy holidays! '+\
		'your total is $60.\n19:30\thappy holidays! your total is $60.\n20:30\thappy holidays! your total is $60.\n21:30\thappy holidays! your total is $60.'+\
		'\n22:30\thappy holidays! your total is $60.\n'
	
	## (price_chart(2,1,5,False)
	elif (num_games == 2) and (num_people == 1) and (day == 5) and (is_holiday == False):
		return 'Price Chart:\n------------------------------\n8:30\tyour total is $6.\n9:30\tyour total is $6.\n10:30\tyour total is $6.'+\
		'\n11:30\tyour total is $6.\n12:30\tyour total is $6.\n13:30\tyour total is $6.\n14:30\tyour total is $6.\n15:30\tyour total is $6.'+\
		'\n16:30\tyour total is $6.\n17:30\tyour total is $6.\n------------------------------\n18:30\tyour total is $12.\n19:30\tyour total is $12.'+\
		'\n20:30\tyour total is $12.\n21:30\tyour total is $12.\n22:30\tyour total is $12.\n'