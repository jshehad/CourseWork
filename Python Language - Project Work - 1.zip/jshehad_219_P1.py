#-------------------------------------------------------------------------------
# Name: Jihad Shehadeh
# Project 1
# Due Date: 2/5/2017
#-------------------------------------------------------------------------------
# Honor Code Statement: I received no assistance on this assignment that
# violates the ethical guidelines set forth by professor and class syllabus.
#-------------------------------------------------------------------------------
# References: Used none
#-------------------------------------------------------------------------------
# Comments and assumptions: None
#-------------------------------------------------------------------------------
# NOTE: width of source code should be <= 80 characters to be read on-screen.
#2345678901234567890123456789012345678901234567890123456789012345678901234567890
#		10 		  20		30		  40		50		  60		70		  80
#-------------------------------------------------------------------------------

# Convert fps to mph
fps_2_mph = float(0.681818182)

# Convert miles to feet
miles_2_feet = float(0.00018939)

# Questions for uer input
first_city = input('What is the name of the first city? ')

train1_fps = int(input('How fast is the train from the first city'+\
' traveling (in feet per second)? '))

second_city = input('What is the name of the second city? ')

train2_fps = int(input('How fast is the train from the second city'+\
' traveling (in feet per second)? '))

distance_between = int(input('How far away are the two cities (in miles)? '))

# Results from user input
print('\nFirst city:',first_city, end=""'; ')
print('Second city:',second_city, end=""'; ')
print('Distance:',distance_between,'miles')

# Train 1 (miles per hour)
train1_mph = train1_fps * fps_2_mph 
print('First train speed:',int(train1_mph),'mph', end=""'; ')

# Train 2 (miles per hour)
train2_mph = (train2_fps * fps_2_mph) 
print('Second train speed:',int(train2_mph), 'mph')

# Total time
time = distance_between / (train1_mph + train2_mph)

# Total time in seconds
total_time = (distance_between / miles_2_feet) / (train1_fps + train2_fps)

# Distance
print('Train One will meet Train Two after approximately', 
int((time * train1_mph) * 5280),'feet.' )

# Distance
print('Train Two will meet Train One after approximately',
int((time * train2_mph) * 5280),'feet.' )

# Setting ETA
days = total_time // 86400 # Total time is secs / by secs in a day
ntime = days * 86400
xhrs = total_time - ntime
hrs = xhrs // 3600
secs = hrs * 3600
nsecs = xhrs - secs
mins = nsecs // 60
msecs = mins * 60
xsecs = nsecs - msecs

print('The two trains will meet after:', int(days), 'days,' , int(hrs), 
'hours,' , int(mins), 'minutes, and' , int(xsecs), 'seconds.')







