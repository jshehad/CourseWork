#-------------------------------------------------------------------------------
# Name: Jihad Shehadeh
# Project 3
# Due Date: 3/05/2017
#-------------------------------------------------------------------------------
# Honor Code Statement: I received no assistance on this assignment that
# violates the ethical guidelines set forth by professor and class syllabus.
#-------------------------------------------------------------------------------
# References: Used none
#-------------------------------------------------------------------------------
# Comments and assumptions: None
#-------------------------------------------------------------------------------
# NOTE: width of source code should be <= 80 characters to be read on-screen.
#2345678901234567890123456789012345678901234567890123456789012345678901234567890
#		10 		  20		30		  40		50		  60		70		  80
#-------------------------------------------------------------------------------

	#	Scored 13 out of 13
def sum_of_digits(n):
    sum = 0
    while (n != 0):
        sum += n % 10
        n //= 10
    return sum

	#	Scored 14 out of 14
def multiply_until_total_reached(original,total,n):	
	counter = 0
	newn = original # starting point
	xs = original # end point
	while (xs < total): # is Original greater than total ?
		newn *= n
		xs += newn
		counter += 1 # add one to counter per iteration
	else:
		return counter # return how many times it went thru the loop
		
	#	Scored 14 out of 14
def replicate(xs,n):
	y=[] 
	for x in xs:
		for i in range(n): # length of n
			# replicate the old list with each element of the length of n
			y.append(x) 
	return y # new list
	
	#	Scored 13 out of 13
def locate_second_divisor(xs,n):
	newlist = [] # start an index counter
	countd = 0 # counting how many nums are divisible by n
	for i in xs:
		if countd < 2: # counting up until to the second divisor
			if ((n % i) == 0): # is it divisible ?
				countd += 1 # add 1 for divisible
				newlist.append(1) # add 1 into the newlist
			else:
				newlist.append(0) # add 0 if it is not divisible
		
	if (len(newlist)-1) <= 0 or sum(newlist) == 0:
		print (None)
	elif countd == 1:
		print (None)
	else:
		return len(newlist)-1 # num in length mines 1 is the index
		
	#	Scored 9 out of 13 failed 4 cases
def all_primes(xs):
	res = list(xs)
	# prime numbers are greater than 1
	for i in res:
		if i > 1:
			# check for factors
			for i in range(2,len(res)):
				if (res[i]%i) == 0:
					return False
					break
			else:
				return True
		else:
			return False

	#	Scored 13 out of 13
def count_2d(xss, v):
	newlist =[] 
	for i in xss: # in list xss
		for j in i: # in subset of list xss
			if (j == v): # do they equal ?
				newlist.append(j) # add it to the new list
	return len(newlist) # call the length size of the new lst