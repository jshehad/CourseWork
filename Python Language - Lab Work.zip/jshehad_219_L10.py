#-------------------------------------------------------------------------------
# Name: Jihad Shehadeh
# Lab 10
# Due Date: 04/10/2017
#-------------------------------------------------------------------------------
# Honor Code Statement: I received no assistance on this assignment that
# violates the ethical guidelines set forth by professor and class syllabus.
#-------------------------------------------------------------------------------
# References: Used none
#-------------------------------------------------------------------------------
# Comments and assumptions: None
#-------------------------------------------------------------------------------
# NOTE: width of source code should be <= 80 characters to be read on-screen.
#2345678901234567890123456789012345678901234567890123456789012345678901234567890
#		10 		  20		30		  40		50		  60		70		  80
#-------------------------------------------------------------------------------

def count_starts(text):
	dict = {}
	for word in text:
		if word:
			if word[0] in dict:
				dict[word[0]] = dict[word[0]] + 1
			else:
				dict[word[0]] = 1
		elif word == '':
			dict[None] = 1
	return dict
	
def get_by_diet(animal_d, diet):
	type = []
	for key,value in animal_d.items():
		if value == diet:
			type.append(key)
	return sorted(type)
	
def merge(d1,d2):
	z = d1.copy()
	z.update(d2)
	return z
	
	