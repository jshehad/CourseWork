# STUDENTS: TO USE:
# 
# The following command will test all test cases on your file:
# 
#   python3 <thisfile.py> <your_one_file.py>
# 
# 
# You can also limit the tester to only the functions you want tested.
# Just add as many functions as you want tested on to the command line at the end.
# Example: to only run tests associated with func1, func2, and func3, run this command:
# 
#   python3 <thisfile.py> <your_one_file.py> func1 func2 func3
# 


# INSTRUCTOR: TO PREPARE:
#  - add test cases to class AllTests. The test case functions' names must
# be precise - to test a function named foobar, the test must be named "test_foobar_#"
# where # may be any digits at the end, such as "test_foobar_13".
# - any extra-credit tests must be named "test_extra_credit_foobar_#"
# 
# - name all required definitions in REQUIRED_DEFNS. Do not include any unofficial 
#   helper functions. If you want to make helper definitions to use while testing,
#   those can also be added there for clarity.
# 
# to run on either a single file or all .py files in a folder (recursively):
#   python3 <thisfile.py> <your_one_file.py>
#   python3 <thisfile.py> <dir_of_files>
# 
# A work in progress by Mark Snyder, Oct. 2015.
#  Edited by Yutao Zhong, Spring 2016.
#  Edited by Raven Russell, Spring 2017.


import unittest
import shutil
import sys
import os
import time
import filecmp

import importlib

############################################################################
############################################################################
# BEGIN SPECIALIZATION SECTION (the only part you need to modify beyond 
# adding new test cases).

# name all expected definitions; if present, their definition (with correct
# number of arguments) will be used; if not, a decoy complainer function
# will be used, and all tests on that function should fail.
	
REQUIRED_DEFNS = [	"counts_from_file",
				 ]

extra_credit = [  ]

weight_required = 10
weight_extra_credit = 1


RENAMED_FILE = "student"

INPUTFILE = "infile.txt"

def create_file(contents, name=INPUTFILE):
		f = open(name,"w")
		f.write(contents)
		f.close()

			
# END SPECIALIZATION SECTION
############################################################################
############################################################################



# enter batch mode by giving a directory to work on.
BATCH_MODE = (sys.argv[1] in ["."] or os.path.isdir(sys.argv[1]))

# This class contains multiple "unit tests" that each check
# various inputs to specific functions, checking that we get
# the correct behavior (output value) from completing the call.
class AllTests (unittest.TestCase):

	def test_counts_from_file_1(self): create_file("1\n"); self.assertEqual(counts_from_file(INPUTFILE),{1:1});try_remove(INPUTFILE,3);
	def test_counts_from_file_2(self): create_file("1\n10\n100\n"); self.assertEqual(counts_from_file(INPUTFILE),{1:1,10:1,100:1});try_remove(INPUTFILE,3);
	def test_counts_from_file_3(self): create_file("1\n1\n1\n2\n3\n3\n3\n3\n5\n"); self.assertEqual(counts_from_file(INPUTFILE),{1:3,2:1,3:4,5:1});try_remove(INPUTFILE,3);
	def test_counts_from_file_4(self): create_file("100\n100\n3\n100\n9\n9\n"); self.assertEqual(counts_from_file(INPUTFILE),{100:3, 3:1, 9:2});try_remove(INPUTFILE,3);
	def test_counts_from_file_5(self): create_file("13\n13\n13\n13\n13\n13\n13\n13\n13\n13\n13\n13\n13\n13\n13\n13\n"); self.assertEqual(counts_from_file(INPUTFILE),{13:16});try_remove(INPUTFILE,3);
	def test_counts_from_file_6(self): create_file("-2\n"); self.assertEqual(counts_from_file(INPUTFILE),{-2:1});try_remove(INPUTFILE,3);
	def test_counts_from_file_7(self): create_file("-2\n-2\n0\n-100\n0\n0\n"); self.assertEqual(counts_from_file(INPUTFILE),{0:3,-2:2,-100:1});try_remove(INPUTFILE,3);
	def test_counts_from_file_8(self): create_file("3\n4\n0\n-1\n4\n0\n-1\n3\n"); self.assertEqual(counts_from_file(INPUTFILE),{0:2,3:2,-1:2,4:2});try_remove(INPUTFILE,3);
	def test_counts_from_file_9(self): create_file("32\n12\n22\n72\n12\n12\n12\n62\n32\n52\n32\n"); self.assertEqual(counts_from_file(INPUTFILE),{12:4,22:1,32:3,52:1,62:1,72:1});try_remove(INPUTFILE,3);
	def test_counts_from_file_10(self): create_file(""); self.assertEqual(counts_from_file(INPUTFILE),{});try_remove(INPUTFILE,3);



# This class digs through AllTests, counts and builds all the tests,
# so that we have an entire test suite that can be run as a group.
class TheTestSuite (unittest.TestSuite):
	# constructor.
	def __init__(self,wants):
		# find all methods that begin with "test".
		fs = []
		for w in wants:
			for func in AllTests.__dict__:
				# append regular tests
				# drop any digits from the end of str(func).
				dropnum = str(func)
				while dropnum[-1] in "1234567890":
					dropnum = dropnum[:-1]
				
				if dropnum==("test_"+w+"_") and (not (dropnum==("test_extra_credit_"+w+"_"))):
					fs.append(AllTests(str(func)))
				if dropnum==("test_extra_credit_"+w+"_") and not BATCH_MODE:
					fs.append(AllTests(str(func)))
		
		# call parent class's constructor.
		unittest.TestSuite.__init__(self,fs)

class TheExtraCreditTestSuite (unittest.TestSuite):
		# constructor.
		def __init__(self,wants):
			# find all methods that begin with "test_extra_credit_".
			fs = []
			for w in wants:
				for func in AllTests.__dict__:
					if BATCH_MODE and str(func).startswith("test_extra_credit_"+w):
						fs.append(AllTests(str(func)))
		
			# call parent class's constructor.
			unittest.TestSuite.__init__(self,fs)

# all (non-directory) file names, regardless of folder depth,
# under the given directory 'dir'.
def files_list(dir):
	info = os.walk(dir)
	filenames = []
	for (dirpath,dirnames,filez) in info:
#		print(dirpath,dirnames,filez)
		if dirpath==".":
			continue
		for file in filez:
			filenames.append(os.path.join(dirpath,file))
#		print(dirpath,dirnames,filez,"\n")
#		filenames.extend(os.path.join(dirpath, filez))
	return filenames

def main():
	if len(sys.argv)<2:
		raise Exception("needed student's file name as command-line argument:"\
			+"\n\t\"python3 tester4L.py gmason76_2xx_L4.py\"")
	want_all = len(sys.argv) <=2
	wants = []
	
	# remove batch_mode signifiers from want-candidates.
	want_candidates = sys.argv[2:]
	for i in range(len(want_candidates)-1,-1,-1):
		if want_candidates[i] in ['.'] or os.path.isdir(want_candidates[i]):
			del want_candidates[i]
	
	if not want_all:
		#print("args: ",sys.argv)
		for w in want_candidates:
			if w in REQUIRED_DEFNS:
				wants.append(w)
			else:
				raise Exception("asked to limit testing to unknown function '%s'."%w)
	else:
		wants = REQUIRED_DEFNS

	if not BATCH_MODE:
		#time.sleep(1) #make sure there is a time gap between last check run and this one
		#run_file(sys.argv[1],wants)
		if not want_all:
			run_file(sys.argv[1],wants)
		else:
			if len(extra_credit) == 0:
				(tag, passed1,tried1,ec) = run_file(sys.argv[1],wants)

				print('='*40)
				print("\nTest cases: %d/%d passed" % (passed1,tried1) )
				print("Score based on test cases: %.0f/100" % (passed1*weight_required))
			
			else:	
				print("Testing required functions:")			
				(tag, passed1,tried1,ec) = run_file(sys.argv[1],wants[:-len(extra_credit)])
				if passed1 == None:
					return

				print("\nTesting extra credit functions:")			
				(tag, passed2,tried2,ec) = run_file(sys.argv[1],extra_credit)
				if passed2!= None:
					print('='*40)
					print("Required test cases: %d/%d passed" % (passed1,tried1) )
					print("Extra credit test cases: %d/%d passed" % (passed2, tried2))
					print("Score based on test cases: %.2f (%.2f+%d) " % (passed1*weight_required+passed2*weight_extra_credit, 
														passed1*weight_required, passed2*weight_extra_credit))

				else:
					print('='*40)
					print("Required test cases: %d/%d passed" % (passed1,tried1) )
					print("Extra credit test cases: 0 passed")
					print("Score based on test cases: %.2f (%.2f+0) " % (passed1*weight_required, 
														passed1*weight_required))

	else:
		filenames = files_list(sys.argv[1])
	
# 		print(filenames)
	
		results = []
		for filename in filenames:
			try:
				print("\n\n\nRUNNING: "+filename)
				(tag, passed,tried,ec) = run_file(filename,wants)
				results.append((tag,passed,tried,ec))
			except SyntaxError as e:
				results.append((filename+"_SYNTAX_ERROR",0,1))	
			except NameError as e:
				results.append((filename+"_Name_ERROR",0,1))	
			except ValueError as e:
				results.append(filename+"_VALUE_ERROR",0,1)
			except TypeError as e:
				results.append(filename+"_TYPE_ERROR",0,1)
			except ImportError as e:
				results.append((filename+"_IMPORT_ERROR_TRY_AGAIN	",0,1))	
			except Exception as e:
				results.append(filename+str(e.__reduce__()[0]),0,1)
			
		print("\n\n\nGRAND RESULTS:\n")
		for (tag, passed, tried, ec) in results:
			print(("%.0f%%  (%d/%d, %dEC) - " % (passed/tried*100 + ec, passed, tried, ec))+tag)

def try_copy(filename1, filename2, numTries):
	have_copy = False
	i = 0
	while (not have_copy) and (i < numTries):
		try:
			# move the student's code to a valid file.
			shutil.copy(filename1,filename2)
			
			# wait for file I/O to catch up...
			if(not wait_for_access(filename2, numTries)):
				return False
				
			have_copy = True
		except PermissionError:
			print("Trying to copy "+filename1+", may be locked...")
			i += 1
			time.sleep(1)
	
	if(i == numTries):
		return False
	return True
			
def try_remove(filename, numTries):
	removed = False
	i = 0
	while os.path.exists(filename) and (not removed) and (i < numTries):
		try:
			os.remove(filename)
			removed = True
		except OSError:
			print("Trying to remove "+filename+", may be locked...")
			i += 1
			time.sleep(1)
	if(i == numTries):
		return False
	return True

def wait_for_access(filename, numTries):
	i = 0
	while (not os.path.exists(filename) or not os.access(filename, os.R_OK)) and i < numTries:
		print("Waiting for access to "+filename+", may be locked...")
		time.sleep(1)
		i += 1
	if(i == numTries):
		return False
	return True

# this will group all the tests together, prepare them as 
# a test suite, and run them.
def run_file(filename,wants=[]):
	if(not try_copy(filename,"student.py", 5)):
		print("Failed to copy " + filename + " to student.py.")
		quit()
	
	# import student's code, and *only* copy over the expected functions
	# for later use.
	import imp
	count = 0
	while True:
		try:
			import student
			imp.reload(student)
			break
		except ImportError as e:
			print("import error getting student.. trying again. "+os.getcwd(), os.path.exists("student.py"))
			time.sleep(0.5)
			count+=1
			if count>3:
				raise ImportError("too many attempts at importing!")
		except SyntaxError as e:
			print("SyntaxError in "+filename+":\n"+str(e))
			print("Run your file without the tester to see the details")
			return((filename+"_SYNTAX_ERROR",None,1,0))
		except NameError as e:
			print("NameError in "+filename+":\n"+str(e))
			print("Run your file without the tester to see the details")
			return((filename+"_Name_ERROR",None,1,0))	
		except ValueError as e:
			print("ValueError in "+filename+":\n"+str(e))
			print("Run your file without the tester to see the details")
			return(filename+"_VALUE_ERROR",None,1,0)
		except TypeError as e:
			print("TypeError in "+filename+":\n"+str(e))
			print("Run your file without the tester to see the details")
			return(filename+"_TYPE_ERROR",None,1,0)
		except ImportError as e:			
			print("ImportError in "+filename+":\n"+str(e))
			print("Run your file without the tester to see the details or try again")
			return((filename+"_IMPORT_ERROR_TRY_AGAIN	",None,1,0))	
		except Exception as e:
			print("Exception in loading"+filename+":\n"+str(e))
			print("Run your file without the tester to see the details")
			return(filename+str(e.__reduce__()[0]),None,1,0)
		#except Exception as e:
		#	print("didn't get to import student yet... " + e)
	# but we want to re-load this between student runs...
	# the imp module helps us force this reload.s
	
	import student
	imp.reload(student)
	
	# make a global for each expected definition.
	def decoy(name):
		return (lambda x: "<no '%s' definition found>" % name)
		
	for fn in wants:#REQUIRED_DEFNS
		globals()[fn] = decoy(fn)
		try:
			globals()[fn] = getattr(student,fn)
		except:
			print("\nNO DEFINITION FOR '%s'." % fn)	
			if fn in extra_credit:
				return ("no extra",0,0,0)
	
	# create an object that can run tests.
	runner1 = unittest.TextTestRunner()
	
	# define the suite of tests that should be run.
	suite1 = TheTestSuite(wants)
	
	# let the runner run the suite of tests.
	ans = runner1.run(suite1)
	num_errors   = len(ans.__dict__['errors'])
	num_failures = len(ans.__dict__['failures'])
	num_tests    = ans.__dict__['testsRun']
	num_passed   = num_tests - num_errors - num_failures
	# print(ans)

	if BATCH_MODE:
		# do the same for the extra credit.
		runnerEC = unittest.TextTestRunner()
		suiteEC = TheExtraCreditTestSuite(wants)
		ansEC = runnerEC.run(suiteEC)
		num_errorsEC   = len(ansEC.__dict__['errors'])
		num_failuresEC = len(ansEC.__dict__['failures'])
		num_testsEC    = ansEC.__dict__['testsRun']
		num_passedEC   = num_testsEC - num_errorsEC - num_failuresEC
		print(ansEC)
	else:
		num_passedEC = 0
	
	# remove our temporary files.
	if os.path.exists("__pycache__"):
		shutil.rmtree("__pycache__", ignore_errors=True)
	if(not try_remove("student.py", 5)):
		print("Failed to copy " + filename + " to student.py.")
	
	tag = ".".join(filename.split(".")[:-1])
	return (tag, num_passed, num_tests,num_passedEC)

# this determines if we were imported (not __main__) or not;
# when we are the one file being run, perform the tests! :)
if __name__ == "__main__":
	main()

