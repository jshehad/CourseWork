def counts_from_file(filename):
	n= []
	d = {}
	f = open(filename, 'r')
	t = f.read().strip().split('\n')
	for i in t:
		if i.isdigit():
			n.append(int(i))
	for i in n:
		if i in d:
			d[i] = d[i] + 1
		else:
			d[i] = 1
	return d
	f.close()