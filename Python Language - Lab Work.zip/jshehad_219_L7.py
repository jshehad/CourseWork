#-------------------------------------------------------------------------------
# Name: Jihad Shehadeh
# Lab 7
# Due Date: 3/20/2017
#-------------------------------------------------------------------------------
# Honor Code Statement: I received no assistance on this assignment that
# violates the ethical guidelines set forth by professor and class syllabus.
#-------------------------------------------------------------------------------
# References: Used none
#-------------------------------------------------------------------------------
# Comments and assumptions: None
#-------------------------------------------------------------------------------
# NOTE: width of source code should be <= 80 characters to be read on-screen.
#2345678901234567890123456789012345678901234567890123456789012345678901234567890
#		10 		  20		30		  40		50		  60		70		  80
#-------------------------------------------------------------------------------

def count_digit_leading_lines(text):
	counter = 0
	newtext = []
	text = text.split("\n")
	for x in text:
		newtext.append(x[0])
	for i in newtext:
		if i == "0" or i == "1" or i == "2" or i == "3" or i == "4" or i == "5" or i == "6" or i == "7" or i == "8" or i == "9":
			counter += 1
	return counter	

def date(month, day, year):
	month = str(month)
	day = str(day)
	year = str(year)
	while 1 <= len(year) < 4:
		year = "0" + year
	if 1 <= len(month) < 2:
		month = "0" + month
		if 1 <= len(day) < 2:
			day = "0" + day
	elif 1 <= len(day) < 2:
		day = "0" + day	
	return '{0}/{1}/{2}' .format(month,day,year)
	
def show_table(list):
	chart = ""
	colwidth = []
	templist = []
	# iterate through each item of first list
	for y in range(len(list[0])):
		templist.append([])
		# iterate through each list
		for x in range(len(list)):
			# create a list for each column
			templist[y].append(list[x][y])
	# create a list of max column widths
	for y in range(len(templist)):
		max = 0
		for a in templist[y][:]:
			if len(a) > max:
				max = len(a)
		colwidth.append(max)
	# pad each list item to the max length
	for y in list[:]:
		for x in range(len(colwidth)):
			y[x] = y[x].ljust(colwidth[x])
	for z in range(len(list)):
		chart +=  "| " + (" | ".join(list[z])) + " |\n"
	return chart