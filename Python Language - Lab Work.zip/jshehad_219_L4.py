def color_mixer(red, green, blue):
	if (255 >= red > 0) and (255 >= green > 0) and (blue == 0):
		return 'yellow'
	elif (255 >= red > 0) and (green == 0) and (255 >= blue > 0):
		return 'magenta'
	elif (red == 0) and (255 >= green > 0) and (255 >= blue > 0):
		return 'cyan'
	elif (255 >= red > 0) and (255 >= green > 0) and (255 >= blue > 0):
		return 'white'
	elif (red == 0) and (green == 0) and (blue == 0):
		return 'black'
	elif (255 >= red > 0) and (green == 0) and (blue == 0):
		return 'red'
	elif (red == 0) and (255 >= green > 0) and (blue == 0):
		return 'green'
	elif (red == 0) and (green == 0) and (255 >= blue > 0):
		return 'blue'
	else:
		return 'bad color!'