#-------------------------------------------------------------------------------
# Name: Jihad Shehadeh
# Lab 11
# Due Date: 04/17/2017
#-------------------------------------------------------------------------------
# Honor Code Statement: I received no assistance on this assignment that
# violates the ethical guidelines set forth by professor and class syllabus.
#-------------------------------------------------------------------------------
# References: Used none
#-------------------------------------------------------------------------------
# Comments and assumptions: None
#-------------------------------------------------------------------------------
# NOTE: width of source code should be <= 80 characters to be read on-screen.
#2345678901234567890123456789012345678901234567890123456789012345678901234567890
#		10 		  20		30		  40		50		  60		70		  80
#-------------------------------------------------------------------------------

def locate(filename,s):
	file = open(filename, 'r')
	lines = file.readlines()
	file.close()
	location = []
	count = 0
	for word in lines:
		if s in word:
			count += 1
			location.append(count)
		else:
			count += 1
	return location
	
def store(d,filename):
	file = open(filename, 'w')
	dictlist = []
	keys = []
	values = []
	colon = []
	x = []
	newl = ''
	for key, value in sorted(d.items()):
		keys.append(key)
		values.append(value)
	order = sorted(dictlist)
	for i in keys:
		colon.append(i+':\t')
	for i in values:
		x.append(str(i).replace(']','\n').replace('[','').replace(', ',',\t'))
	for i in range(len(colon)):
		newl+=(colon[i]+x[i])
	file.write(newl)
	file.close()

def append_total(filename):
	total = []
	with open(filename) as data:
		for line in data:
			segment = line.strip()
			if segment.isdigit():
				total.append(int(segment))
	updated_data = 'Total:' + str(sum(total)) + '\n'
	with open(filename,'a') as data:
		data.write(updated_data)