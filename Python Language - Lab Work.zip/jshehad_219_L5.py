#-------------------------------------------------------------------------------
# Name: Jihad Shehadeh
# laboratory Assignment 5
# Due Date: 2/27/2017
#-------------------------------------------------------------------------------
# Honor Code Statement: I received no assistance on this assignment that
# violates the ethical guidelines set forth by professor and class syllabus.
#-------------------------------------------------------------------------------
# References: Used none
#-------------------------------------------------------------------------------
# Comments and assumptions: None
#-------------------------------------------------------------------------------
# NOTE: width of source code should be <= 80 characters to be read on-screen.
#2345678901234567890123456789012345678901234567890123456789012345678901234567890
#		10 		  20		30		  40		50		  60		70		  80
#-------------------------------------------------------------------------------
	
	# Factoring Evens
def factorial_evens(num):
	factorial = 1
# Check for correct integer
	if num < 0:
		return 'Sorry, try something positive'
# Check for zeros
	elif num == 0:
		return 'The factorial of 0 is 1'
# Checking whether it is even or odd number 
	elif (num % 2) == 0:
		for i in range(num,1,-2):
			factorial = factorial*i
		return factorial
	else:
		for i in range(2,num,+2):
			factorial = factorial*i
		return factorial
		
	# Adding Lists
def add_subtract_list(xs):
	sumval = 0
	res = list(xs)
	for i in range(1,len(res),2): 
		if i % 1 == 0:
# Multiplying everyother number by -1
			res[i] = res[i]*-1
	for i in range(len(xs)):
		sumval += res[i]
	return sumval

	# Finding Multiples
def find_multiples(n, xs):
	multiples_of_n = []
	for i in range(1,len(xs)+1):
		if i % n == 0:
			multiples_of_n.append(i)
	return (multiples_of_n)	
	
def last_index(xs,key):
    index = -1
# Checking for the last index
    for i in range(len(xs)):
        if xs[i] == key:
            index = i           
    if index != -1:
        return index
    else:
        return None