#-------------------------------------------------------------------------------
# Name: Jihad Shehadeh
# Laboratory Assignment 13
# Due Date: 05/01/2017
#-------------------------------------------------------------------------------
# Honor Code Statement: I received no assistance on this assignment that
# violates the ethical guidelines set forth by professor and class syllabus.
#-------------------------------------------------------------------------------
# References: Used none
#-------------------------------------------------------------------------------
# Comments and assumptions: None
#-------------------------------------------------------------------------------
# NOTE: width of source code should be <= 80 characters to be read on-screen.
#2345678901234567890123456789012345678901234567890123456789012345678901234567890
#		10 		  20		30		  40		50		  60		70		  80
#-------------------------------------------------------------------------------

class Course:
    def __init__(self, number, credit, grade):
        self.number = number
        self.credit = credit
        scale = ['A', 'B', 'C', 'D', 'F', 'IP']
        if grade in scale:
            self.grade = grade
        else:
            raise CourseError("bad grade '" + str(grade) + "'")
   
    def __str__(self):
        return self.number + ": credit " + str(self.credit) + ", grade " + self.grade
   
    def __eq__(self,other):
        return self.number==other.number and self.credit==other.credit and self.grade==other.grade
    def is_passing(self):
        return not (self.grade == 'F' or self.grade == 'IP')
 
class Transcript:
    def __init__(self):
        self.courses = []
    def __str__(self):
        transcript = "Transcript:\n\t"
        for course in self.courses:
            transcript += str(course) + "\n\t"
        return transcript[:-1]
    def __eq__(self,other):
        return self.courses == other.courses
   
    def add_course(self, course):
        for section in self.courses:
            if course == section:
                raise CourseError("duplicate course number '" + course.number + "'")
        self.courses.append(course)
 
    def course_by_number(self, number):
        for course in self.courses:
            if course.number == number:
                return course
        return None
 
    def course_by_grade(self, grade):
        grade_list = []
        for course in self.courses:
            if course.grade == grade:
                grade_list.append(course)
        return grade_list
    def total_passing_credit(self):
        total_hours = 0
        for course in self.courses:
            if course.is_passing():
                total_hours += course.credit
        return total_hours

class CourseError(Exception):
    def __init__(self, msg):
        self.msg = msg
    def __str__(self):
        return self.msg