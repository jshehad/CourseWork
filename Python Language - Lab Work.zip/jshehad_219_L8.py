#-------------------------------------------------------------------------------
# Name: Jihad Shehadeh
# Lab 8
# Due Date: 3/27/2017
#-------------------------------------------------------------------------------
# Honor Code Statement: I received no assistance on this assignment that
# violates the ethical guidelines set forth by professor and class syllabus.
#-------------------------------------------------------------------------------
# References: Used none
#-------------------------------------------------------------------------------
# Comments and assumptions: None
#-------------------------------------------------------------------------------
# NOTE: width of source code should be <= 80 characters to be read on-screen.
#2345678901234567890123456789012345678901234567890123456789012345678901234567890
#		10 		  20		30		  40		50		  60		70		  80
#-------------------------------------------------------------------------------

def simple_pig_latin(input, sep=" ", end="."):
	VOWELS = ("a" or "e" or "i" or "o" or "u")
	new = [] 
	input = input.split(sep)
	#print(input)
	for word in input:
		if word[0] == "a" or "e" or "i" or "o" or "u":
			new.append(word + 'way')
				
		elif word[0] != "a" or "e" or "i" or "o" or "u":
			new.append(word[1:] + word[0] + 'ay')		
	print ((sep).join(new) + end)
	
def replace(xs,old,new,limit=None):
	if limit==None:
		n = 0
		for i in xs:
			if i == old:
				xs[n] = new
				n += 1
			else:
				n += 1
		return xs
	#cant replace a word
	elif type(new) == str:
		return None
	
	#return none to an empty list
	elif xs == []:
		return None
	elif (0 < limit > len(xs)):
		n = 0
		for i in xs:
			if i == old:
				xs[n] = new
				n += 1
			else:
				n += 1
		return xs
	
# limit Cant be a negative #
	elif limit < 0:
		return xs		
	elif (0 < limit < len(xs)):
		n = 0
		x = 0
		for i in xs:
			if x < limit:
				if i == old:
					xs[n] = new
					n += 1
					x += 1
				else:
					n += 1
		return xs

def extract_negatives(xs, new_home=None):
	if new_home == None:
		i = 0
		while i < len(xs):
			if xs[i] < 0:
				xs.remove(xs[i])
			else:
				i += 1
		return xs